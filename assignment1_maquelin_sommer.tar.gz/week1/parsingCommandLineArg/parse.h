#ifndef PARSINGCOMMANDLINEARG_PARSE_H
#define PARSINGCOMMANDLINEARG_PARSE_H

char* read_line();
char** split_line(char* line);
char** split_line2(char *line);

#endif //PARSINGCOMMANDLINEARG_PARSE_H
